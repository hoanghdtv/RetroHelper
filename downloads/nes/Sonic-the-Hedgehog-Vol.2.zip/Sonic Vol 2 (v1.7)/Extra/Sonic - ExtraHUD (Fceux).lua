
while (true) do

 oxigeno1 = 61 - tonumber(memory.readbyte(0x009a));
 oxigeno2 = tonumber(oxigeno1,16);
 
personaje = memory.readbyte(0x00032b);
  enemigo = memory.readbyte(0x00032c);
  
   fondo1 = memory.readbyte(0x00032d);
   fondo2 = memory.readbyte(0x00032e);
   fondo3 = memory.readbyte(0x00032f);
   fondo4 = memory.readbyte(0x000330);
   


       gui.text(22,43, string.format( "Aire: %02X", oxigeno2) );

       gui.text(210,224, string.format("Sonic: %02X", personaje));
	   gui.text(170,224, string.format("Obj: %02X", enemigo));
	   
	   gui.text(3,224, string.format("Grx:"));
	   gui.text(25,224, string.format("%02X", fondo1));
	   gui.text(40,224, string.format("%02X", fondo2));
	   gui.text(55,224, string.format("%02X", fondo3));
	   gui.text(70,224, string.format("%02X", fondo4));
       emu.frameadvance();

end;

