Among Us
The Tragedy of Ryohyukan (1993)

By Takashi Endo
Published in magazine – Micom BASIC (マイコン BASIC) 1994/01

Preserved by Ozidual (Twitter) with thanks to Dustin Hubbard
https://www.gamingalexandria.com/wp/2022/02/nintendo-family-basic-type-in-games/

ROMhack by Garrett Gilchrist

__________________________

There are imposters among us! Find them. Mark them. Stop them before they kill the entire crew of this spaceship.

The Tragedy of Ryohyukan (Ryuuhyoukan no Sangeki) is a 1993 NES/Famicom minigame programmed in Famicom Family BASIC V3 by Takashi Endo and published over three pages of the magazine "Micom BASIC (マイコン BASIC)" in early 1994. That is our source for the code.

Graphics and text have been changed in this version to translate the minigame from Japanese, and reflect the 2018 PC game Among Us, by Innersloth, Marcus Bromander and Forest Willard.

This is a ROMhack by Garrett Gilchrist. The game originally used the generic Family BASIC graphics (derived from Mario Bros, Binary Land, and so on). It's possible that more could be done with the backgrounds and sprites.

This is a standalone ROM prepared as an IPS patch of Family BASIC 3 (1985).

Special thanks to Ozidual.

__________________________

HOW TO PLAY:

In The Tragedy of Ryohyukan there is a group of red crewmates on the screen and your job as detective is to find the imposter killer(s) and mark them pink/purple.

You can move your cursor with the D-Pad over 9 spots, although only the 8 outside ones matter. All the crewmates start in the bottom middle square and move counter-clockwise, mostly in a group, although staggered.

Press A to change the movement direction of the crewmates currently standing still, and split them up.

Press B to mark all the crewmates standing still as killers, or unmark them.

Press Start to see if you’ve marked all the killers (and just killers) pink/purple.

If you did, a little devil marker appears above their head(s) and you win the stage.

You get points for living crewmates and bonus points for speed. Or maybe for living killers identified since I believe killers can kill killers.

There is a timer in the upper right corner with pink rectangles that disappear over time. If you run out of pink rectangles, you lose. If the killers kill all the innocents, you lose. You can lose up to 3 times before it resets you back to the main screen.

You start with 1 out of eight crewmembers as an imposter. The imposters will increase in number and the crewmates decrease in number.

You can use the left/right and up/down D-pad arrows on the title screen to choose number of crewmates and game speed (low/high).

__________________________

TRANSLATING:

Japanese text was translated to English from context, and the text removed to make space for the new title graphic.

ニン モ-ド シュウリョウ was translated as END OF CREWMATE ENDURANCE MODE but this is just a guess. I think one crewmate is removed at this point.

__________________________


HACKING AND REPRODUCING THE FAMILY BASIC CODE:

I was given ozidual's Family BASIC code as text and rewrote it to my liking, including more text on the title screen (to make room for graphics later) and English text elsewhere.

The original is actually two programs, with the first setting up the background layout during gameplay, and some other variables. Typing both together would result in out of memory errors, so I focused on the second program which contains the game.

NinTaco has a lot of features to copy/paste, load/save and autotype Family BASIC code, but the results weren't working. Noticeably the auto type feature was screwing up pretty frequently, and the copy/pasted code was noticeably different from the public ROM (typed manually by ozidual in VirtuaNES, which I didn't want to do).

NesTopia has an autotype feature which worked a lot better but has no debug features. It has a tape record output which didn't seem to work at first. I switched to an unofficial version of Nestopia and got some tape output once I'd exited the program, saved as a TP file under "Saves."

This is using the Family Basic SAVE"TEST" (or the name of your file) command in Nestopia.

I then loaded this into VirtuaNES, renamed as a VTP file, using the Family Basic LOAD command.

The Nestopia .tp file format is a headerless unsigned 8-bit PCM wave file with a 32000 Hz sampling rate. (The VirtuaNES format is identical.) You can do an "Import Raw Data" in Audacity (https://i.imgur.com/cHQGg.png) and save it as a wav file.

VirtuaNES has a memory viewer but no output for it.

However, a VirtuaNES save state can be converted to NES by a program called STTONES.

"You need to have a Family Basic V3.0 ROM renamed to FAMIBE_V3.nes and STTONES in the same folder. Then run FAMIBE_V3 in VirtuaNES, load the code, run the code, and BREAK out of the code (using the End key).  Then create a save state in VirtuaNES.  It creates a FAMIBE_V3.st0 file that you can drop on STTONES."

There is an obvious problem with this method. STTONES is designed to be run when the entire program has been typed but not run. Unfortunately this is impossible with this method, which is transferring between programs using audio, which doesn't seem to be saved to RAM in quite the same way.

So, when you've got a Save State, open up your hex editor. There should be program data in the VirtuaNES Save State at about 0A14. Copy all of that data to about 2A14. Some FFs at the beginning will have to become 00s.

Now I run STTONES and have a more or less working file, which I used for further hacking.

The actual problem was this: The FAMIBAS_V3.nes ROM I was using doesn't say it has a battery-backed WRAM segment (the part that stores the game). Therefore VirtuaNES doesn't have the 0x2000 extra bytes that STTONES wants: You need to set 0x6 from 01 to 03.

Alternately we can use the Python remake STTONED.PY :
Usage: sttoned.py path/to/save_state path/to/family_basic.nes 
https://gist.github.com/einstein95/f33906cd4ee0c6e1abae0b4141e08ea9

The new title graphic was created in Photoshop and Shiru's NES Screen Tool, and copied into the ROM using YY-CHR.