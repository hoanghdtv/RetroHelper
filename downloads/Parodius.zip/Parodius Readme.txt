======================================================
===================Parodius da!=========================
======================V1.00===========================
Genre: Shooter

Source language: Japanese

Patch language: English

Author: Pennywise/Tom

E-mail: yojimbogarrett@gmail.com
       translatortom@hotmail.com
http://yojimbo.eludevisibility.org/
 
======================================================
Parodius da!
======================================================
Background: I remember wanting to do this game sometime in
2009 when I discovered it had stuff to translate. If I
had made a serious attempt at hacking it, I probably
wouldn't have been able to get the job done. However, that
was then and this is now. Hacking this game turned out to
be a rather quick process and Tom did an awesome job with
the ending lyrics. Not much else to say.

If you've never heard of Parodius, now would be the time
to look it up. This is the second game in the series
and this particular game was ported to variety of systems.
For an NES game, it is amazing what they pulled off and
the whole game looks very impressive. Unfortunately,
the game also showcases one of the NES's biggest limitations
of how many sprites it can display at a time. This explains
the reason why the game flickers.

This game was actually released in Europe by Palcom back
in the day, but they changed the ending music and removed
the song lyrics at the end. I find this to be detrimental
to the gaming experience and makes beating the game less
fun and rewarding. The ending is one of the highlights of
the game. Luckily that's not the case with our translation.

======================================================
Game Tips
======================================================

There are extra stages in levels 1, 3, 5, and 6.

Stage 1: Equip a weapon that doesn't fire straight...
(Like the RIPPLE or DOUBLE weapon) and fire at the
ceiling just past the first pirate ship. The ceiling
will break open and you can go up into the sky stage.
Start shooting early, because if you break it open
too late, the screen won't pan up, and you can't enter
the stage.

Stage 3: When the roller coaster takes a downward
turn, there's a wall that seals shut at the top of
the screen. Blow the wall open, and continue to the
right before the screen pans down. If it pans to the
right, you're in the new stage. If it doesn't, you're
dead. (Be prepared to die many times before you get
into this stage.)

Stage 5: Blow the mouth apart at the front of the
spaceship, and then enter the mouth.

Stage 6: The second time you enter the water, you'll
see a black square with sparkles. Touch it to enter
the last extra stage.

======================================================
Notes from the translator
======================================================

After finishing a different project with Pennywise,
I asked if there were any other Famicom games that
included sing-along songs at the end.

To my surprise, Pennywise recommended a game that I
had bought a few years back, but had never finished.
It was Parodius. A few other people also sent me
an e-mail about it as well. I had no idea it had such
an interesting ending.

Eventually, Pennywise sent me the lyrics, and I
translated them as soon as I got them. I had a
blast doing it. I listened to the ending song
several times (on youtube) to get a sense of the
rhythm, then started counting syllables and was able
to fit the translation to music. It turned out even
better than I expected.

I stayed as close as possible to the meaning of the
original while still making sure that the lyrics
were fun and memorable.

My favorite part of the song is:

"Parodius, oooh!"

Note: "Oooh" is pronounced like the French "Oooh la la!"
(I just want to make sure you don't pronounce it "OH.")

The phonemes of the Japanese language dictate that
the last syllable of "Parodius" is pronounced as "SU."
By changing it to "Parodius, oooh!" I managed to
keep the flow and match the rhythm in a fun way!

My hope is that, upon getting to the end of the
game, you will sing along with the ending song!

If you happen to sing along with the ending song and
post a youtube video of it, that would absolutely
make my day! Let me know!

======================================================
Patching Instructions
======================================================
The patch is in the BPS format and needs to be applied
with byuu's patcher, beat.

These are some of the links where you can download it.
The patching process is the same as IPS.

http://byuu.org/programming/beat/
http://www.romhacking.net/utilities/893/
http://www.smwcentral.net/?p=section&a=details&id=5917

Apparently beat has issues working on XP, but I've been
told the third link works on XP.

Apply the patch to the original Japanese version of the
ROM:

Parodius Da! (Japan).nes

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated. There is a Japanese graphic for "END"
that I haven't been able to find in-game. I have
a suspicion that it might be part of a hidden ending.
In my experience of hacking and translating Konami
games, there are usually hidden messages/endings
that are usually triggered by specific button presses
when you beat the game.   

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - main hacking, testing.

Tom - translation, testing.

sin_batsu - title screen design

DvD - ROM Expander Program

i88gerbils - Special Thanks

ReyVGM - Special Thanks

All those who contributed into this process.

======================================================


Compiled by Pennywise. October 2013.
